
import java.util.ArrayList;

public interface Player {
	public void makeMove(ArrayList<String> availableMoves);
}
